﻿namespace Infnet.Engesoft.SysBank.Model.Dominio
{
    public interface IEndereco
    {
    }
}

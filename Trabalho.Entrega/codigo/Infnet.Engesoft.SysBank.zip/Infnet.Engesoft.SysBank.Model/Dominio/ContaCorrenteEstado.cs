﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infnet.Engesoft.SysBank.Model
{
    public enum ContaCorrenteEstado
    {
        Ativa,
        Bloqueada,
        Fechada
    }

}

﻿
namespace Infnet.Engesoft.SysBank.Model
{
    public class Agencia
    {
        public string Nome     { get; set; }
        public string Numero   { get; set; }
        public int CodigoBanco { get; set; }
    }
}

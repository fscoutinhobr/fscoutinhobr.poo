﻿
namespace Infnet.Engesoft.SysBank.Model.Dominio
{
    public class PessoaFisica : Pessoa
    {
        public string Cpf { get; set; }
        public decimal Renda { get; set; }
    }
}

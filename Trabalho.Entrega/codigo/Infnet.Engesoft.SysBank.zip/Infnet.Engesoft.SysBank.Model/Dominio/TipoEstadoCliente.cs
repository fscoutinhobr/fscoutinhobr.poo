﻿namespace Infnet.Engesoft.SysBank.Model
{
    public enum TipoEstadoCliente
    {
        Potencial,
        Ativo
    }
}

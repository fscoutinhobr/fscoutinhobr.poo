﻿namespace Infnet.Engesoft.SysBank.Model
{
    public enum TipoTelefone 
    { 
        Comercial, 
        Celular, 
        Residencial 
    }
}

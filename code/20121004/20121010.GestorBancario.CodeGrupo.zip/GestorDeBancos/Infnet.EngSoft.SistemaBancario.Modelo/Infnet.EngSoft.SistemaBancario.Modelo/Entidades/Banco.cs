﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infnet.EngSoft.SistemaBancario.Modelo
{
    public class Banco
    {
        public string RazaoSocial { set; get; }
        public string NomeFantasia { set; get; }
        public string Agencia { set; get; }

    }
}

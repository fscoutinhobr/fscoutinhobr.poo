﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Infnet.EngSoft.SistemaBancario.Modelo;
using NUnit.Framework;

namespace Infnet.EngSoft.SistemaBancario.Model.Teste
{
    [TestFixture]
    public class EnderecoTeste
    {
        [Test]
        public void TesteTipoDeLogradouro()
        {
            string tipoLogradouro = @"Rua";

            Endereco endereco = new Endereco();
            endereco.TipoDeLogradouro = tipoLogradouro;

            Assert.AreEqual(tipoLogradouro, endereco.TipoDeLogradouro);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Infnet.EngSoft.SistemaBancario.Modelo;
using NUnit.Framework;

namespace Infnet.EngSoft.SistemaBancario.Model.Teste
{
    [TestFixture]
    public class TelefoneTeste
    {
        [Test]
        public void Telefone()
        {
            string Tel = @"88277979";

            Telefone telefone = new Telefone;
            telefone.DDD = Tel;

        }
    }
}

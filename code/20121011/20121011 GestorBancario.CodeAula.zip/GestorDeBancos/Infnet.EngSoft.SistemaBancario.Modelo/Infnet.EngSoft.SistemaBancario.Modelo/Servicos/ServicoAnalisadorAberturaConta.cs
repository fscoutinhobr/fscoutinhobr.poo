﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infnet.EngSoft.SistemaBancario.Modelo.Servicos
{
    public class ServicoAnalisadorAberturaConta
    {
        // método para analisar solicitação de Abertura de Conta Corrente
        public bool AnalisarSolicitacaoAberturaContaCorrente()
        {
            return true;
        }
    }
}

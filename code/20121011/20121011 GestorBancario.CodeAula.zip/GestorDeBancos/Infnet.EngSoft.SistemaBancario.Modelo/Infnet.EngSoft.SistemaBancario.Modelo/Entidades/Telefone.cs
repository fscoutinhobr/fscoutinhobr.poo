﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infnet.EngSoft.SistemaBancario.Modelo
{
    public class Telefone
    {
        public int DDD {get; set;}
        public int Numero {get; set;}
        public String Tipo {get; set;}

    }
}
